package math

import (
	"exercise/message"
	"fmt"
)

//
// This function will take an integer number and apply several checks to it
// while explaining its properties to the user by printing messages to the
// screen.
//
// IMPORTANT NOTE: The domain of numbers we are going to work with are the
//                 POSITIVE INTEGERS (num > 0). Any other number has to be
//                 rejected by the function.
//
func CheckAndExplainNumber(num2Check int) {
	// If the number to check is negative we just omit it
	if num2Check <= 0 {
		fmt.Println("We require positive integers to work.")
		return
	}

	// 0 reciprocal number
	reciprocal := getReciprocalNumber(float64(num2Check))
	message.ReciprocalMsg(float64(num2Check), reciprocal)

	// 1 parity
	isEven := isEven(num2Check)
	message.ParityMsg(num2Check, isEven)

	// 2 prime
	isPrime := isPrime(num2Check)
	message.PrimeMsg(num2Check, isPrime)

	// If it is prime we will apply some prime checks, otherwise we will apply
	// non prime checks.
	if isPrime {
		// 3a twin prime :: If the number is prime, check if it has a twin prime
		hasTwin, twin := checkTwins(num2Check)
		message.TwinPrimeMsg(num2Check, hasTwin, twin)

		// 4a cousin prime :: If the number is prime, check if it has a cousin prime
		hasCousin, cousing := checkCousins(num2Check)
		message.CousinPrimeMsg(num2Check, hasCousin, cousing)

	} else {
		// 3b primer factors :: if the number is not prime, get one of its factors
		factor := getOnePrimeFactor(num2Check)
		message.PrimeFactorMsg(num2Check, factor)
	}
}
