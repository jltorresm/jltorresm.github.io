package math

// Function to get the reciprocal of a given number
func getReciprocalNumber(num float64) float64 {
	// Your code goes here
}

// Function that returns true if a number is even, otherwise it returns false.
func isEven(num int) bool {
	// Your code goes here
}

// Returns true is a number is prime, otherwise false
func isPrime(num int) bool {
	// Your code goes here
}

// Function that checks if a number has a twin prime. It returns true and a
// valid twin or false and 0 otherwise.
func checkTwins(num int) (bool, int) {
	// Your code goes here
}

// Function that checks if a number has a cousin prime. It returns true and a
// valid cousin or false and 0 otherwise.
func checkCousins(num int) (bool, int) {
	// Your code goes here
}

func primeGap(num , gap int) (bool, int) {
	// Your code goes here
}

// Function that returns any prime factor of a composite number.
// e.g.: 6 has prime factors 2 and 3, the function returns either.
func getOnePrimeFactor(num int) int {
	// Your code goes here
}
