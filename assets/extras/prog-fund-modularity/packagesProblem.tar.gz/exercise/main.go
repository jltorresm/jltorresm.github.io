package main

import (
	"exercise/math"
	"fmt"
)

//
// Main function
//   - This is the entry point of our program
//   - This function iterates from -1 to 100
//   - For each of those numbers it will call math.CheckAndExplainNumber to
//     apply some tests to that number and print a short explanation.
//
func main() {
	// Your code goes here
}
