package message

import (
	"fmt"
)

//
// Each function in this file prints an explanatory message for a particular
// numeric test defined in math/check.go
//

// e.g. The reciprocal of 4 is 0.25 because 4.00 * 0.25 = 1.00
func ReciprocalMsg(n, r float64) {
	// Your code goes here
}

// e.g. The number 2 is even
//      The number 3 is NOT even
func ParityMsg(n int, isEven bool) {
	// Your code goes here
}

// e.g. The number 5 IS prime
//      The number 4 IS NOT prime
func PrimeMsg(num2Check int, isPrime bool) {
	// Your code goes here
}

// e.g. The number 3 has a twin: 5
//      The number 2 has no twins
func TwinPrimeMsg(num2Check int, hasTwin bool, twin int) {
	// Your code goes here
}

// e.g. The number 3 has a cousin: 7
//      The number 5 has no cousins
func CousinPrimeMsg(num2Check int, hasCousin bool, cousing int) {
	// Your code goes here
}

// e.g. The number 25 is divisible by 5
func PrimeFactorMsg(num2Check, factor int) {
	// Your code goes here
}
