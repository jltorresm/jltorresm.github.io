package message

import (
	"fmt"
)

//
// Each function in this file prints an explanatory message for a particular
// numeric test defined in math/check.go
//

// e.g. The reciprocal of 4 is 0.25 because 4.00 * 0.25 = 1.00
func ReciprocalMsg(n, r float64) {
	fmt.Printf("The reciprocal of %d is %f because %.2f * %f = %.2f\n", int(n), r, n, r, n * r)
}

// e.g. The number 2 is even
//      The number 3 is NOT even
func ParityMsg(n int, isEven bool) {
	if isEven {
		fmt.Printf("The number %d is even\n", n)
	} else {
		fmt.Printf("The number %d is NOT even\n", n)
	}
}

// e.g. The number 5 IS prime
//      The number 4 IS NOT prime
func PrimeMsg(num2Check int, isPrime bool) {
	if isPrime {
		fmt.Printf("The number %d IS prime\n", num2Check)
	} else {
		fmt.Printf("The number %d IS NOT prime\n", num2Check)
	}
}

// e.g. The number 3 has a twin: 5
//      The number 2 has no twins
func TwinPrimeMsg(num2Check int, hasTwin bool, twin int) {
	if hasTwin {
		fmt.Printf("The number %d has a twin: %d\n", num2Check, twin)
	} else {
		fmt.Printf("The number %d has no twins\n", num2Check)
	}
}

// e.g. The number 3 has a cousin: 7
//      The number 5 has no cousins
func CousinPrimeMsg(num2Check int, hasCousin bool, cousing int) {
	if hasCousin {
		fmt.Printf("The number %d has a cousin: %d\n", num2Check, cousing)
	} else {
		fmt.Printf("The number %d has no cousins\n", num2Check)
	}
}

// e.g. The number 25 is divisible by 5
func PrimeFactorMsg(num2Check, factor int) {
	fmt.Printf("The number %d is divisible by %d\n", num2Check, factor)
}
