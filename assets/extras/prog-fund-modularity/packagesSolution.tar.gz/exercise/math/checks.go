package math

// Function to get the reciprocal of a given number
func getReciprocalNumber(num float64) float64 {
	return float64(1) / float64(num);
}

// Function that returns true if a number is even, otherwise it returns false.
func isEven(num int) bool {
	if num % 2 == 0 {
		return true
	}

	return false
}

// Returns true is a number is prime, otherwise false
func isPrime(num int) bool {
	if num <= 1 {
		return false
	}

	for i := 2; i <= num/2; i++ {
		if num%i == 0 {
			return false
		}
	}

	return true
}

// Function that checks if a number has a twin prime. It returns true and a
// valid twin or false and 0 otherwise.
func checkTwins(num int) (bool, int) {
	var gap = 2

	if gapIsPrime, whichPrime := primeGap(num, gap); gapIsPrime {
		return true, whichPrime
	}

	return false, 0
}

// Function that checks if a number has a cousin prime. It returns true and a
// valid cousin or false and 0 otherwise.
func checkCousins(num int) (bool, int) {
	var gap = 4

	if gapIsPrime, whichPrime := primeGap(num, gap); gapIsPrime {
		return true, whichPrime
	}

	return false, 0
}

func primeGap(num , gap int) (bool, int) {
	var possitiveGap, negativeGap int = num + gap, num - gap

	if isPrime(possitiveGap) {
		return true, possitiveGap
	} else if isPrime(negativeGap) {
		return true, negativeGap
	}

	return false, 0
}

// Function that returns any prime factor of a composite number.
// e.g.: 6 has prime factors 2 and 3, the function returns either.
func getOnePrimeFactor(num int) int {
	// To handle the special case of a small number we just say that the number is
	// divisible by itself (which is true btw)
	if num <= 2 {
		return num
	}

	for possibleFactor := 2; possibleFactor <= num/2; possibleFactor++ {
		// We check divisibility only if the number is prime
		if isPrime(possibleFactor) && num%possibleFactor == 0 {
			return possibleFactor
		}
	}

	panic("Trying to get factors of a prime number")
}
