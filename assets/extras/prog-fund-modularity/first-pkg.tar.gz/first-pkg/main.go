//
// main.go
//
package main

import (
	"first-pkg/say"
)

func main() {
	say.Hello()
	say.ANumber()
}
