package say

import (
	"fmt"
	"math/rand"
	"time"
)

func Hello() {
	anything("hello")
}

func ANumber() {
	rand.Seed(time.Now().UnixNano())
	anything(rand.Intn(10))
}

func anything(msg interface{}) {
	fmt.Println(msg)
}

